const $ = (selector) => document.querySelector(selector);
let authMode = 'login';
let toastTimer;

function showMessage(element, message, type = '') {
  element.textContent = message;
  element.className = `form-message ${type}`.trim();
}
function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    credentials: 'same-origin'
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}
function setAuthMode(mode) {
  authMode = mode;
  const registering = mode === 'register';
  $('#loginTab').classList.toggle('active', !registering);
  $('#registerTab').classList.toggle('active', registering);
  $('#nameField').classList.toggle('hidden', !registering);
  $('#name').required = registering;
  $('#password').autocomplete = registering ? 'new-password' : 'current-password';
  $('#authSubmit').textContent = registering ? 'Create account →' : 'Log in securely →';
  showMessage($('#authMessage'), '');
}
function updateUserUI(user) {
  const loggedIn = Boolean(user);
  $('#welcomeName').textContent = loggedIn ? `Hi, ${user.name}` : '';
  $('#logoutBtn').classList.toggle('hidden', !loggedIn);
  $('#loginNav').classList.toggle('hidden', loggedIn);
  $('#reportForm').querySelectorAll('input, select, textarea, button').forEach(el => el.disabled = !loggedIn);
  if (!loggedIn) {
    $('#totalReports').textContent = '—';
    $('#categoryCount').textContent = '—';
    $('#latestDate').textContent = '—';
    $('#reportsList').innerHTML = '<div class="empty-state"><div class="empty-icon">⌕</div><h3>Log in to see your reports</h3><p>Your incident reports are linked to your account.</p><a class="text-link" href="#auth">Log in or create an account →</a></div>';
  }
}
function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 'Date unavailable' : date.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
async function loadReports() {
  try {
    const data = await api('/api/reports');
    const items = data.reports;
    $('#totalReports').textContent = items.length;
    $('#categoryCount').textContent = new Set(items.map(item => item.category)).size;
    $('#latestDate').textContent = items.length ? new Date(items[0].createdAt).toLocaleDateString([], { day: 'numeric', month: 'short' }) : 'None yet';
    if (!items.length) {
      $('#reportsList').innerHTML = '<div class="empty-state"><div class="empty-icon">＋</div><h3>No reports submitted yet</h3><p>Use the incident form above to submit your first report.</p><a class="text-link" href="#reportSection">Create a report →</a></div>';
      return;
    }
    $('#reportsList').innerHTML = items.map(item => `
      <article class="report-card">
        <div class="report-card-top"><h3>${escapeHTML(item.title)}</h3><span class="pill">${escapeHTML(item.status || 'Submitted')}</span></div>
        <span class="pill">${escapeHTML(item.category)}</span>
        <p class="report-description">${escapeHTML(item.description)}</p>
        <div class="report-location">⌖ &nbsp;${escapeHTML(item.location)}</div>
        <div class="report-meta"><span>Report ID: ${escapeHTML(String(item._id).slice(-6).toUpperCase())}</span><span>${escapeHTML(formatDate(item.createdAt))}</span></div>
      </article>`).join('');
  } catch (error) {
    if (error.message === 'Please log in first.') updateUserUI(null);
    else showToast(error.message);
  }
}
async function refreshSession() {
  try {
    const data = await api('/api/me');
    updateUserUI(data.user);
    if (data.user) await loadReports();
  } catch (error) {
    showToast(error.message);
  }
}

$('#loginTab').addEventListener('click', () => setAuthMode('login'));
$('#registerTab').addEventListener('click', () => setAuthMode('register'));
$('#authForm').addEventListener('submit', async event => {
  event.preventDefault();
  const body = {
    name: $('#name').value.trim(),
    email: $('#email').value.trim(),
    password: $('#password').value
  };
  const endpoint = authMode === 'register' ? '/api/register' : '/api/login';
  $('#authSubmit').disabled = true;
  showMessage($('#authMessage'), authMode === 'register' ? 'Creating your account…' : 'Logging you in…');
  try {
    const data = await api(endpoint, { method: 'POST', body: JSON.stringify(body) });
    showMessage($('#authMessage'), data.message, 'success');
    updateUserUI(data.user);
    $('#authForm').reset();
    await loadReports();
    showToast(data.message);
    setTimeout(() => $('#dashboard').scrollIntoView({ behavior: 'smooth' }), 250);
  } catch (error) {
    showMessage($('#authMessage'), error.message, 'error');
  } finally {
    $('#authSubmit').disabled = false;
  }
});

$('#reportForm').addEventListener('submit', async event => {
  event.preventDefault();
  const body = {
    title: $('#title').value.trim(),
    category: $('#category').value,
    location: $('#location').value.trim(),
    description: $('#description').value.trim()
  };
  const submit = $('#reportForm').querySelector('button[type="submit"]');
  submit.disabled = true;
  showMessage($('#reportMessage'), 'Submitting your report…');
  try {
    const data = await api('/api/reports', { method: 'POST', body: JSON.stringify(body) });
    showMessage($('#reportMessage'), data.message, 'success');
    $('#reportForm').reset();
    await loadReports();
    showToast('Report submitted successfully.');
    $('#dashboard').scrollIntoView({ behavior: 'smooth' });
  } catch (error) {
    showMessage($('#reportMessage'), error.message, 'error');
    if (error.message === 'Please log in first.') document.querySelector('#auth').scrollIntoView({ behavior: 'smooth' });
  } finally {
    submit.disabled = false;
  }
});

$('#logoutBtn').addEventListener('click', async () => {
  try {
    const data = await api('/api/logout', { method: 'POST', body: '{}' });
    updateUserUI(null);
    showToast(data.message);
    setAuthMode('login');
    await refreshSession();
  } catch (error) {
    showToast(error.message);
  }
});
$('#refreshBtn').addEventListener('click', loadReports);
refreshSession();
